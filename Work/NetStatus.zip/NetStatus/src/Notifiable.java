/**
 * Created by r-ken on 10/19/2016.
 */
public interface Notifiable {

    public void Notify();
}
