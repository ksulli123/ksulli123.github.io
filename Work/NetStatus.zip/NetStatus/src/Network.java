/**
 * Created by r-ken on 10/19/2016.
 */
import jdk.nashorn.internal.objects.Global;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;


public class Network{


    private CentralHub chub = new CentralHub(0);
    private Map<String, Hub> hubs = new HashMap<String, Hub>();      //Name of hub and hub variable
    private Map<String, Node> nodes = new HashMap<String, Node>();    //Name of node and node variable
    private Map<String, House> houses = new HashMap<String, House>();  //

    public Network(){



        String fileloc = "data/set3/";

        chub = new CentralHub(0);

        try {


            FileReader hubReader = new FileReader(fileloc + "hubs.txt");
            FileReader nodeReader = new FileReader(fileloc + "nodes.txt");
            FileReader homeReader = new FileReader(fileloc + "homes.txt");
            FileReader outReader = new FileReader(fileloc + "outages.txt");
            String line;
            String x;
            String y;
            Point loc;
            String delim = " ";
            String name;
            String[] parts;

            try(BufferedReader br = new BufferedReader(hubReader)){ //Initializes hub map variables

                while ((line = br.readLine()) != null){
                    parts = line.split(delim);
                    name = parts[0];
                    x = parts[1];
                    y = parts[2];
                    loc = new Point(Integer.parseInt(x), Integer.parseInt(y));  //Initialize point variable, convert x y strings to int
                    Hub newhub = new Hub(loc, 0, chub);

                    //System.out.println(name + " " + x +  " " + y);

                    //hubs = new HashMap<String, Hub>();
                    hubs.put(name, newhub);
                }

            } catch (IOException e){
                System.err.println("File is not found.");
            }

            try(BufferedReader br = new BufferedReader(nodeReader)) {

                String nname;
                String hname;

                while ((line = br.readLine()) != null) {

                    parts = line.split(delim);

                    nname = parts[0];
                    x = parts[1];
                    y = parts[2];
                    hname = parts[3];
                    loc = new Point(Integer.parseInt(x), Integer.parseInt(y));

                    Node node = new Node(hubs.get(hname), loc, 0);

                    //System.out.println(nname + " " + x + " " + y );

                    //nodes = new HashMap<String, Node>();
                    nodes.put(nname, node);

                }


            } catch(IOException e){
                System.err.println("File is not found.");
            }


            try(BufferedReader br = new BufferedReader(homeReader)) {

                String nname;
                String address;

                while ((line = br.readLine()) != null) {
                    parts = line.split(" ");
                    address = parts[0];
                    nname = parts[1];

                    Node node = nodes.get(nname);
                    House house = new House(node);

                    //houses = new HashMap<String, House>();
                    houses.put(address, house);

                }
            } catch (IOException e){
                System.err.println("File is not found.");
            }

            try(BufferedReader br = new BufferedReader(outReader)){

                String address;
                while ((line = br.readLine()) != null) {
                    address = line;


                                for (Map.Entry<String, House> entry : houses.entrySet()) {

                                    //System.out.println(entry.getKey());

                                    if (entry.getKey().equals(address)){
                                        //System.out.println(address);
                                        entry.getValue().Notify();
                                    }
                                }

                                //houses.get(address).Notify();

                }


            } catch (IOException e){
                System.err.println("File not found.");
            }



        } catch (IOException e){
            System.err.println("File not found.");
        }
    }
    
    
    public void Draw(Graphics2D g2){

        for (Map.Entry<String, Node> entry : nodes.entrySet()){
            entry.getValue().draw(g2);
        }



        for (Map.Entry<String, Hub> entry : hubs.entrySet()){
            entry.getValue().draw(g2);

            Point hubPoint = entry.getValue().getHubLoc();
            g2.setColor(Color.BLACK);
            g2.drawString(entry.getKey(), hubPoint.x+10, hubPoint.y+10);
        }

        chub.draw(g2);
    }
    
}
