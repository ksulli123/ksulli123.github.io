/**
 * Created by r-ken on 10/19/2016.
 */
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.security.cert.PolicyNode;

public class Hub implements Drawable, Notifiable{
    private CentralHub parent;
    private Point loc;
    private int failures;
    private Point parentloc = new Point(100,100);

    public Hub(Point loc, int failures, CentralHub parent){
        this.parent = parent;
        this.loc = loc;
        this.failures = failures;
    }

    @Override
    public void Notify(){
        if (this.failures==2){
            parent.Notify();
        }
        failures++;
        //System.out.println("Hub notified!");

    }

    @Override
    public void draw(Graphics2D g2) {

        if (failures>1){
            Line2D lin = new Line2D.Float(loc.x, loc.y, 100, 100);
            g2.setColor(Color.RED);
            g2.draw(lin);
            Ellipse2D.Double circle = new Ellipse2D.Double(loc.x-5, loc.y-5, 10, 10);
            g2.fill(circle);

        } else{
            Line2D lin = new Line2D.Float(loc.x, loc.y, 100, 100);
            g2.setColor(Color.GREEN);
            g2.draw(lin);

            Ellipse2D.Double circle = new Ellipse2D.Double(loc.x-5, loc.y-5, 10, 10);
            g2.fill(circle);
        }
    }


    public Point getHubLoc(){
        Point thisPoint = this.loc;

        return thisPoint;
    }
}
