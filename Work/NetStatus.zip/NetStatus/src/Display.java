import javax.swing.*;
import java.awt.*;

/**
 * Created by r-ken on 10/19/2016.
 */
public class Display extends JComponent {

    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        Network n = new Network();
        n.Draw(g2);
    }
}
