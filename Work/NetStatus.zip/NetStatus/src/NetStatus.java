/**
 * Created by r-ken on 10/19/2016.
 */
import javax.swing.*;
import java.io.*;

public class NetStatus {

    public static void main(String args[])throws FileNotFoundException{

        JFrame F = new JFrame("Network Status");
        F.setSize(550, 550);


        F.setDefaultCloseOperation(
            JFrame.EXIT_ON_CLOSE);
        F.add(new Display());
        F.setVisible(true);
    }
}
