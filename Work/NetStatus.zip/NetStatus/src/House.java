/**
 * Created by r-ken on 10/19/2016.
 */
import java.awt.Point;


public class House implements Notifiable {
    private Node parent;

    public House(Node parent){
        this.parent = parent;
    }

    @Override
    public void Notify(){
        //System.out.println("House notified!");
        parent.Notify();
    }
}
