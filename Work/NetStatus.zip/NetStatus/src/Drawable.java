import java.awt.*;

/**
 * Created by r-ken on 10/19/2016.
 */
public interface Drawable {
    public void draw(Graphics2D g2);
}
