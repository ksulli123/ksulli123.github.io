import java.awt.*;

/**
 * Created by r-ken on 10/19/2016.
 */
public class CentralHub implements Drawable, Notifiable{
    private int failures;

    public CentralHub(int failures){
        this.failures = failures;
    }

    @Override
    public void draw(Graphics2D g2){


        System.out.println(failures);

        if (failures>=2) {
            System.out.println(failures);
            g2.setColor(Color.RED);
            g2.fillRect(90, 90, 20, 20);
        } else {
            g2.setColor(Color.GREEN);
            g2.fillRect(90, 90, 20, 20);
        }
    }

    @Override
    public void Notify(){

        //System.out.println("Node notified!");
        this.failures++;
    }

}
