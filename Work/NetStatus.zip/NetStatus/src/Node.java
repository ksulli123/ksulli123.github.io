/**
 * Created by r-ken on 10/19/2016.
 */
import java.awt.*;
import java.awt.geom.Line2D;

public class Node implements Drawable, Notifiable{
    private Hub parent;
    private Point loc;
    private int failures;

    public Node(Hub parent, Point loc, int failures){
        this.parent = parent;
        this.loc = loc;
        this.failures = failures;
    }

    @Override
    public void Notify(){

        //System.out.println("Node notified!");
        this.failures++;
        if (this.failures==2) {
            parent.Notify();
        }
    }

    @Override
    public void draw(Graphics2D g2) {

        Point parPoint = parent.getHubLoc();

        if (failures>1){
            Line2D lin = new Line2D.Float(loc.x, loc.y, parPoint.x, parPoint.y);
            g2.setColor(Color.RED);
            g2.draw(lin);
        } else {
            Line2D lin = new Line2D.Float(loc.x, loc.y, parPoint.x, parPoint.y);
            g2.setColor(Color.GREEN);
            g2.draw(lin);
        }

    }
}
