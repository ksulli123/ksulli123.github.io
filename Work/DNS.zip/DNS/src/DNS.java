/**
 * Created by r-ken on 10/16/2016.
 */
import java.util.*;
import java.util.Scanner;

interface BasicDNS{
    abstract void setDN(String ipa, String domain);
    abstract String search(String domain);
}

interface GovDNS{
    abstract void setGovDN(String ipa);
}

public class DNS implements BasicDNS, GovDNS{

    Map<String, String> BDNS = new HashMap<String, String>();
    Set<String> BlackList = new HashSet<String>();


    public void setDN(String ipa, String domain){
        BDNS.put(ipa, domain);
    }

    public String search(String domain){
        String ipa = "";
        for (Map.Entry<String, String> entry : BDNS.entrySet())
        {
            if (entry.getValue().equals(domain)){
                ipa = entry.getKey();
            }
        }

        return ipa;
    }

    public void setGovDN(String ipa){

        boolean found = false;
        for (Map.Entry<String, String> entry : BDNS.entrySet())
        {
            if (BDNS.containsKey(entry.getKey())){
                found = true;
            }
        }
        if (found) {
            BlackList.add(ipa);
        }
        else {
            System.out.println("IPA doesn't exist. Please try a valid ipa.");
        }
    }

    public static void main(String args[]){
        DNS dnobj = new DNS();
        dnobj.setDN("00001","www.google.com");
        dnobj.setDN("00002","www.facebook.com");
        dnobj.setDN("00003","www.youtube.com");
        dnobj.setDN("00004","www.wikipedia.com");
        dnobj.setDN("00005","www.griffith.edu.au");

        dnobj.setGovDN("00001");

        int done = 1;

        while (done!=-1) {
            System.out.println("Please input an option");
            System.out.println("1: Add DNS");
            System.out.println("2: Blacklist ipa");
            System.out.println("3: Look up domain name");
            System.out.println("-1: End program.");

            Scanner in = new Scanner(System.in);
            int x = in.nextInt();

            if (x==1){
                String domain;
                String ipa;
                System.out.println("Please input domain name");
                domain = in.next();
                System.out.println("Please input ipa");
                ipa = in.next();
                dnobj.setDN(ipa, domain);
            }
            else if (x==2){
                String ipa;
                System.out.println("Please input ipa that you want to blacklist");
                ipa = in.next();
                dnobj.setGovDN(ipa);
            }
            else if (x==3){
                String domain;
                System.out.println("Please input domain name to find corresponding ipa");
                domain = in.next();
                String ipa = dnobj.search(domain);

                System.out.println("IPA: " + ipa);
            }
        }
    }
}
